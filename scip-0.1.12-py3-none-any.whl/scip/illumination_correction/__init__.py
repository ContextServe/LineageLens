"""
Illumination correction methods
"""
